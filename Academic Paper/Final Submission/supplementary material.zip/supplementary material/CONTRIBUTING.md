# Contributing to Discrete Polar Lattice

Thank you for your interest in contributing! This document provides guidelines for extending the codebase.

## Development Setup

1. **Clone and install**:
   ```bash
   git clone <repository-url>
   cd cleaned
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

2. **Run tests**:
   ```bash
   pytest tests/ -v
   ```

3. **Run validation**:
   ```bash
   python scripts/validate.py
   ```

## Code Style

- **Docstrings**: Use NumPy-style docstrings for all public functions
- **Type hints**: Add type annotations for function parameters and returns
- **Naming**: 
  - Use full words, not abbreviations (except standard physics notation like `ℓ`, `m_ℓ`)
  - Follow PEP 8 conventions
- **Comments**: Explain "why", not "what" (code should be self-documenting)

## Adding New Features

### Extending to Higher ℓ_max

To test larger systems:

1. Modify `test_*.py` to include additional test cases:
   ```python
   @pytest.mark.parametrize("ℓ_max", [2, 3, 4])
   def test_commutators_parametric(ℓ_max):
       lattice = build_lattice(ℓ_max=ℓ_max)
       ops = build_angular_momentum_operators(lattice)
       results = validate_commutators(ops)
       assert results['passed']
   ```

2. **Performance note**: For ℓ_max > 5, sparse matrix operations become important. Ensure operators remain sparse.

### Adding New Operators

To add a new angular momentum-related operator:

1. Add builder function to `src/operators.py`:
   ```python
   def build_new_operator(lattice: Dict) -> sparse.csr_matrix:
       """
       Build [operator name].
       
       [Mathematical definition and properties]
       """
       # Implementation
       return operator
   ```

2. Add to `build_angular_momentum_operators()` dictionary

3. Write unit test in `tests/test_operators.py` (create if needed)

### Adding Visualizations

Add plotting functions to `src/visualization.py` (create if needed):

```python
def plot_lattice_3d(lattice: Dict, **kwargs) -> Tuple[plt.Figure, plt.Axes]:
    """
    Create 3D spherical lift visualization.
    
    Parameters
    ----------
    lattice : dict
        Lattice dictionary
    **kwargs
        Additional matplotlib options
    
    Returns
    -------
    fig, ax
        Matplotlib figure and 3D axes
    """
    # Implementation
```

Then import and use in notebooks.

## Testing Guidelines

### Writing Tests

1. **Unit tests** (`tests/test_*.py`):
   - Test one thing per test function
   - Use descriptive names: `test_commutator_xy_relation()`
   - Document tolerances explicitly
   - Use `pytest.mark.parametrize` for multiple cases

2. **Integration tests**:
   - Test full workflows (lattice → operators → validation)
   - Use `ℓ_max = 1` for speed, `ℓ_max = 2` for realism

3. **Property-based tests** (optional, requires `hypothesis`):
   - Test algebraic properties (Hermiticity, unitarity, etc.)

### Test Organization

```
tests/
├── test_lattice.py        # Lattice construction and quantum numbers
├── test_operators.py      # Operator builders (new, create if needed)
├── test_commutators.py    # SU(2) algebra
├── test_spectrum.py       # Eigenvalues and degeneracies
└── test_integration.py    # End-to-end workflows (new, create if needed)
```

### Running Specific Tests

```bash
# Run one file
pytest tests/test_commutators.py -v

# Run one test function
pytest tests/test_commutators.py::test_commutators_ℓmax2 -v

# Run with coverage
pytest tests/ --cov=src --cov-report=html
```

## Documentation

### Docstring Template

```python
def function_name(param1: Type1, param2: Type2) -> ReturnType:
    """
    One-line summary.
    
    More detailed description if needed. Explain the mathematical
    or physical meaning, not just the implementation.
    
    Parameters
    ----------
    param1 : Type1
        Description of param1
    param2 : Type2, optional, default=value
        Description of param2
    
    Returns
    -------
    ReturnType
        Description of return value
    
    Notes
    -----
    Additional mathematical details, references, or caveats.
    
    Examples
    --------
    >>> result = function_name(arg1, arg2)
    >>> print(result)
    expected_output
    """
    # Implementation
```

### Updating README

When adding features:
1. Update "Package Structure" if new files added
2. Update "Quick Start" if new scripts added
3. Add examples to demonstrate new functionality

## Pull Request Process

1. **Branch naming**: `feature/description` or `fix/description`
2. **Commit messages**: Descriptive, present tense ("Add spectrum test", not "Added spectrum test")
3. **PR description**:
   - What: What does this PR do?
   - Why: Why is this change needed?
   - How: Brief explanation of approach
   - Tests: What tests were added/modified?
4. **Checklist**:
   - [ ] Tests pass locally (`pytest tests/`)
   - [ ] Validation script passes (`python scripts/validate.py`)
   - [ ] Code follows style guidelines
   - [ ] Docstrings added for new functions
   - [ ] README updated if needed

## Performance Considerations

- **Sparse matrices**: Always use `scipy.sparse` for operators
- **Memory**: For ℓ_max > 10, consider sparse eigenvalue solvers (`scipy.sparse.linalg.eigsh`)
- **Profiling**: Use `cProfile` or `line_profiler` if performance degrades

## Questions?

- **Code implementation**: Open an issue on GitHub
- **Geometric axioms**: Contact the human author (see README)
- **Physical interpretation**: See manuscript and PROVENANCE.md

## License

All contributions are licensed under MIT License (see [LICENSE](LICENSE)).
