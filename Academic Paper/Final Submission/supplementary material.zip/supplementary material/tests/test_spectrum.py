"""
Test L² eigenvalue spectrum and degeneracies for ℓ_max = 2
"""

import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import numpy as np
import pytest

from lattice import build_lattice
from operators import build_angular_momentum_operators
from validation import validate_spectrum


def test_spectrum_ℓmax2():
    """
    Test that L² has eigenvalues ℓ(ℓ+1) with correct degeneracies for ℓ_max = 2.
    
    Expected:
    - ℓ = 0: eigenvalue 0, degeneracy 2
    - ℓ = 1: eigenvalue 2, degeneracy 6
    - ℓ = 2: eigenvalue 6, degeneracy 10
    """
    # Build lattice
    lattice = build_lattice(ℓ_max=2)
    
    # Build operators
    ops = build_angular_momentum_operators(lattice)
    
    # Validate spectrum
    results = validate_spectrum(lattice, ops, tolerance=1e-10)
    
    # Assert all tests pass
    assert results['passed'], (
        f"Spectrum tests failed: "
        f"diagonal={results['is_diagonal']}, "
        f"eigenvalues={results['max_eigenvalue_error']:.2e}, "
        f"degeneracies={results['degeneracies_match']}"
    )
    
    # Specific checks
    assert results['is_diagonal'], "L² is not diagonal"
    assert results['max_eigenvalue_error'] < 1e-10, "Eigenvalues don't match ℓ(ℓ+1)"
    assert results['degeneracies_match'], "Degeneracies don't match 2(2ℓ+1)"


def test_degeneracies_explicit():
    """Explicitly check degeneracy values for ℓ_max = 2."""
    lattice = build_lattice(ℓ_max=2)
    ops = build_angular_momentum_operators(lattice)
    results = validate_spectrum(lattice, ops)
    
    # Check specific degeneracies
    assert results['degeneracies'][0] == 2, "ℓ=0 should have degeneracy 2"
    assert results['degeneracies'][1] == 6, "ℓ=1 should have degeneracy 6"
    assert results['degeneracies'][2] == 10, "ℓ=2 should have degeneracy 10"
    
    # Total should be 2 + 6 + 10 = 18
    total = sum(results['degeneracies'].values())
    assert total == 18, f"Total states should be 18, got {total}"


def test_eigenvalue_spectrum():
    """Test that eigenvalues match ℓ(ℓ+1) exactly."""
    lattice = build_lattice(ℓ_max=2)
    ops = build_angular_momentum_operators(lattice)
    
    L2 = ops['L2']
    L2_diag = L2.diagonal()
    
    # Group by ℓ and check eigenvalues
    for ℓ in range(3):
        # Get all indices for this ℓ
        indices = np.where(lattice['ell'] == ℓ)[0]
        
        # Check eigenvalues
        expected = ℓ * (ℓ + 1)
        for idx in indices:
            actual = np.real(L2_diag[idx])
            assert abs(actual - expected) < 1e-10, (
                f"State {idx} with ℓ={ℓ} has L²={actual:.6f}, expected {expected}"
            )


def test_L2_is_diagonal():
    """Test that L² is diagonal to machine precision."""
    lattice = build_lattice(ℓ_max=2)
    ops = build_angular_momentum_operators(lattice)
    
    L2 = ops['L2']
    L2_dense = L2.toarray()
    L2_diag = np.diag(np.diagonal(L2_dense))
    
    off_diagonal = L2_dense - L2_diag
    off_diag_norm = np.linalg.norm(off_diagonal)
    
    assert off_diag_norm < 1e-10, (
        f"L² has significant off-diagonal elements: norm = {off_diag_norm:.2e}"
    )


def test_total_state_count():
    """Test that total number of states is correct."""
    lattice = build_lattice(ℓ_max=2)
    
    # Should have sum_{ℓ=0}^{2} 2(2ℓ+1) = 2 + 6 + 10 = 18 states
    assert lattice['n_points'] == 18
    
    # Check distribution
    for ℓ in range(3):
        count = np.sum(lattice['ell'] == ℓ)
        expected = 2 * (2 * ℓ + 1)
        assert count == expected, (
            f"ℓ={ℓ} has {count} states, expected {expected}"
        )


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
