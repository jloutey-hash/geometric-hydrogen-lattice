"""
Test SU(2) commutation relations for ℓ_max = 2
"""

import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import numpy as np
import pytest

from lattice import build_lattice
from operators import build_angular_momentum_operators
from validation import validate_commutators


def test_commutators_ℓmax2():
    """
    Test that [L_x, L_y] = i L_z (and cyclic) for ℓ_max = 2.
    
    This is the core numerical claim: the discrete lattice exactly
    reproduces SU(2) angular momentum algebra to machine precision.
    """
    # Build lattice for ℓ_max = 2
    lattice = build_lattice(ℓ_max=2)
    
    # Build operators
    ops = build_angular_momentum_operators(lattice)
    
    # Validate commutators
    results = validate_commutators(ops, tolerance=1e-12)
    
    # Assert all commutators pass
    assert results['passed'], (
        f"Commutators failed: max deviation = {results['max_deviation']:.2e}"
    )
    
    # Individual checks for clarity
    assert results['deviations']['[L_x, L_y] - i*L_z'] < 1e-12
    assert results['deviations']['[L_y, L_z] - i*L_x'] < 1e-12
    assert results['deviations']['[L_z, L_x] - i*L_y'] < 1e-12


def test_commutators_small_system():
    """Test commutators for ℓ_max = 1 (even smaller system)."""
    lattice = build_lattice(ℓ_max=1)
    ops = build_angular_momentum_operators(lattice)
    results = validate_commutators(ops, tolerance=1e-12)
    
    assert results['passed']


def test_hermiticity():
    """Test that L_x, L_y, L_z are Hermitian."""
    lattice = build_lattice(ℓ_max=2)
    ops = build_angular_momentum_operators(lattice)
    
    # Check Hermiticity: A† = A
    for name in ['Lx', 'Ly', 'Lz']:
        A = ops[name]
        A_dense = A.toarray()
        A_dagger = np.conj(A_dense.T)
        
        deviation = np.linalg.norm(A_dense - A_dagger)
        assert deviation < 1e-14, f"{name} is not Hermitian: deviation = {deviation:.2e}"


def test_L2_hermitian():
    """Test that L² is Hermitian and positive semi-definite."""
    lattice = build_lattice(ℓ_max=2)
    ops = build_angular_momentum_operators(lattice)
    
    L2 = ops['L2']
    L2_dense = L2.toarray()
    L2_dagger = np.conj(L2_dense.T)
    
    # Hermiticity
    deviation = np.linalg.norm(L2_dense - L2_dagger)
    assert deviation < 1e-14
    
    # Positive semi-definite (all eigenvalues >= 0)
    eigenvalues = np.linalg.eigvalsh(L2_dense)
    assert np.all(eigenvalues >= -1e-10), "L² has negative eigenvalues"


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
