# Discrete Polar Lattice for Angular Momentum

A minimal, reproducible implementation demonstrating exact SU(2) angular momentum commutation relations on a discrete 2D lattice.

## Origin Story

This package implements a discrete coordinate system for angular momentum that arose from geometric axioms about quantized angular momentum. The human author provided the foundational geometric rules:

- Ring radii: r_ℓ = 1 + 2ℓ
- Point counts: N_ℓ = 2(2ℓ + 1) (encoding orbital and spin degeneracies)
- Quantum number assignment via spin interleaving

AI assistance (Claude/GPT) helped translate these geometric axioms into numerical code, explore edge cases, and verify the algebraic properties. The core discovery—that this simple geometric lattice exactly reproduces SU(2) commutation relations to machine precision—emerged from the interplay between human geometric intuition and AI-assisted numerical exploration.

**This package contains code used to reproduce the numerical claims in the manuscript.** All results are reproducible using the scripts below.

## Key Results

For ℓ_max = 2 (18 states), the code validates:

1. **Exact SU(2) commutators**: [L_x, L_y] = i L_z (and cyclic) with deviations < 10⁻¹²
2. **Correct L² spectrum**: Eigenvalues ℓ(ℓ+1) with degeneracies 2(2ℓ+1)
3. **Deterministic construction**: Simple geometric rules with no free parameters

## Installation

**Requirements**: Python 3.8+

```bash
# Clone repository
git clone <repository-url>
cd cleaned

# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## Quick Start

### Run validation script

```bash
python scripts/validate.py
```

Expected output:
```
============================================================
SU(2) COMMUTATION RELATION VALIDATION
============================================================
...
✅ ALL VALIDATION TESTS PASSED
```

### Run test suite

```bash
pytest tests/ -v
```

Expected: All tests pass in < 10 seconds.

### Run Jupyter notebook

```bash
jupyter notebook notebooks/validate_lmax2.ipynb
```

The notebook produces visualizations and detailed numerical tables.

## Package Structure

```
cleaned/
├── src/                  # Core modules
│   ├── lattice.py        # Lattice construction
│   ├── operators.py      # Angular momentum operators (Lz, L±, L², etc.)
│   ├── graph.py          # Adjacency and Laplacian builders
│   └── validation.py     # Numerical validation utilities
├── tests/                # Unit tests (pytest)
│   ├── test_commutators.py
│   └── test_spectrum.py
├── notebooks/            # Jupyter notebooks
│   └── validate_lmax2.ipynb
├── scripts/              # Command-line scripts
│   └── validate.py
├── README.md
├── requirements.txt
└── LICENSE
```

## Reproducibility Statement

**This package contains code used to reproduce the numerical claims in the manuscript.** The human author provided the geometric axioms; AI assisted in algebraic translation and numerical exploration. All results are reproducible using the scripts above.

The construction is a **coordinate/discretization scheme** for angular momentum, not a claim of physical discovery. The lattice exactly encodes the abstract SU(2) algebra through a concrete discrete geometry.

## Tests

The test suite (`tests/`) validates:

- **test_commutators.py**: SU(2) relations [L_i, L_j] = i ε_ijk L_k with tolerance 10⁻¹²
- **test_spectrum.py**: L² eigenvalues ℓ(ℓ+1), degeneracies 2(2ℓ+1), tolerance 10⁻¹⁰

Tolerances are conservative and explicitly documented in test files.

## Citation

If you use this code, please cite the associated manuscript:

```
[Citation to be added upon publication]
```

## License

MIT License - see [LICENSE](LICENSE) for details.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines on extending the code.

## Contact

For questions about the geometric axioms or physical interpretation, contact the human author. For questions about the code implementation, see [PROVENANCE.md](PROVENANCE.md) for attribution details.
