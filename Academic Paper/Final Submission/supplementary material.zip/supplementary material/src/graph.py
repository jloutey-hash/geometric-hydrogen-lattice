"""
Graph Structure Module
=====================

Constructs adjacency matrices and graph Laplacians for the polar lattice.

This module provides utilities for building connectivity structures:
- Angular neighbors (within same ring)
- Radial neighbors (between adjacent rings)
- k-nearest neighbor graphs
- Normalized graph Laplacians
"""

from typing import Dict, Tuple
import numpy as np
from scipy import sparse
from scipy.spatial import distance_matrix


def build_adjacency_knn(lattice: Dict, k: int = 4) -> sparse.csr_matrix:
    """
    Build k-nearest neighbor adjacency matrix.
    
    Parameters
    ----------
    lattice : dict
        Lattice dictionary from lattice.build_lattice()
    k : int, default=4
        Number of nearest neighbors to connect
    
    Returns
    -------
    scipy.sparse.csr_matrix
        Symmetric adjacency matrix (N x N)
    
    Notes
    -----
    Uses Euclidean distance in 2D. Symmetrizes the result to ensure
    undirected graph. This is the deterministic rule used for operator
    construction.
    """
    points = lattice['points']
    n_points = len(points)
    
    # Compute pairwise distances
    dist_mat = distance_matrix(points, points)
    
    # Build adjacency
    row_indices = []
    col_indices = []
    
    for i in range(n_points):
        # Find k nearest neighbors (excluding self)
        neighbors = np.argsort(dist_mat[i, :])[1:k+1]
        
        for j in neighbors:
            row_indices.append(i)
            col_indices.append(j)
    
    # Create sparse matrix
    data = np.ones(len(row_indices))
    adj = sparse.csr_matrix(
        (data, (row_indices, col_indices)),
        shape=(n_points, n_points)
    )
    
    # Symmetrize
    adj = adj + adj.T
    adj.data = np.ones_like(adj.data)  # Remove double-counting
    
    return adj


def build_degree_matrix(adjacency: sparse.csr_matrix) -> sparse.csr_matrix:
    """
    Build degree matrix from adjacency matrix.
    
    Parameters
    ----------
    adjacency : scipy.sparse.csr_matrix
        Adjacency matrix
    
    Returns
    -------
    scipy.sparse.csr_matrix
        Diagonal degree matrix D_ii = sum_j A_ij
    """
    degrees = np.array(adjacency.sum(axis=1)).flatten()
    return sparse.diags(degrees, format='csr')


def build_laplacian(adjacency: sparse.csr_matrix, 
                   normalized: bool = False) -> sparse.csr_matrix:
    """
    Build graph Laplacian from adjacency matrix.
    
    Parameters
    ----------
    adjacency : scipy.sparse.csr_matrix
        Adjacency matrix
    normalized : bool, default=False
        If True, return normalized Laplacian L = I - D^{-1/2} A D^{-1/2}
        If False, return combinatorial Laplacian L = D - A
    
    Returns
    -------
    scipy.sparse.csr_matrix
        Graph Laplacian matrix
    
    Notes
    -----
    The normalized Laplacian has eigenvalues in [0, 2] and is often
    better conditioned for numerical work.
    """
    D = build_degree_matrix(adjacency)
    
    if not normalized:
        # Combinatorial Laplacian: L = D - A
        return D - adjacency
    else:
        # Normalized Laplacian: L = I - D^{-1/2} A D^{-1/2}
        n = adjacency.shape[0]
        degrees = np.array(D.diagonal())
        
        # Compute D^{-1/2}
        with np.errstate(divide='ignore', invalid='ignore'):
            d_inv_sqrt = np.where(degrees > 0, 1.0 / np.sqrt(degrees), 0)
        
        D_inv_sqrt = sparse.diags(d_inv_sqrt, format='csr')
        
        # L_norm = I - D^{-1/2} A D^{-1/2}
        I = sparse.identity(n, format='csr')
        L_norm = I - D_inv_sqrt @ adjacency @ D_inv_sqrt
        
        return L_norm
