"""
Discrete Polar Lattice for Angular Momentum
============================================

A minimal, reproducible implementation of a discrete 2D polar lattice
that exactly reproduces SU(2) angular momentum commutation relations.

Modules
-------
lattice : Lattice point construction and coordinate mapping
operators : Angular momentum operator construction (Lz, L±, L², etc.)
validation : Numerical validation and testing utilities

Author: Human researcher with AI assistance (see PROVENANCE.md)
"""

__version__ = "0.1.0"

from .lattice import build_lattice
from .operators import build_angular_momentum_operators
from .validation import validate_commutators, validate_spectrum

__all__ = [
    'build_lattice',
    'build_angular_momentum_operators',
    'validate_commutators',
    'validate_spectrum',
]
