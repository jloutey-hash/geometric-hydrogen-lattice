"""
Lattice Construction Module
===========================

Constructs the discrete 2D polar lattice with quantum number assignments.

Geometric Rules (Human-provided axioms):
---------------------------------------
- Ring radius: r_ℓ = 1 + 2ℓ
- Points per ring: N_ℓ = 2(2ℓ + 1)  (encodes 2ℓ+1 orbitals × 2 spins)
- Quantum numbers: Each point labeled by (ℓ, m_ℓ, m_s)
  - ℓ: azimuthal quantum number (ring index)
  - m_ℓ: magnetic quantum number ∈ [-ℓ, ..., +ℓ]
  - m_s: spin quantum number ∈ {-½, +½}

The mapping interleaves spins: even j → m_s = +½, odd j → m_s = -½
"""

from typing import Dict, List, Tuple
import numpy as np


def build_lattice(ℓ_max: int) -> Dict[str, np.ndarray]:
    """
    Build discrete 2D polar lattice up to angular momentum ℓ_max.
    
    Parameters
    ----------
    ℓ_max : int
        Maximum angular momentum quantum number (ℓ = 0, 1, ..., ℓ_max)
    
    Returns
    -------
    dict
        Dictionary containing:
        - 'points': (N, 2) array of (x, y) 2D coordinates
        - 'r': (N,) array of radial coordinates
        - 'theta': (N,) array of angular coordinates
        - 'ell': (N,) array of ℓ quantum numbers
        - 'm_ell': (N,) array of m_ℓ quantum numbers
        - 'm_s': (N,) array of m_s quantum numbers
        - 'index_map': dict mapping (ℓ, m_ℓ, m_s) -> linear index
        
    Notes
    -----
    The lattice constructs concentric rings following the geometric rules.
    Total number of points: N = sum_{ℓ=0}^{ℓ_max} 2(2ℓ+1)
    """
    points_list = []
    r_list = []
    theta_list = []
    ell_list = []
    m_ell_list = []
    m_s_list = []
    
    index_map = {}
    linear_idx = 0
    
    for ℓ in range(ℓ_max + 1):
        # Ring parameters from geometric rules
        r_ℓ = 1 + 2 * ℓ
        N_ℓ = 2 * (2 * ℓ + 1)
        
        for j in range(N_ℓ):
            # 2D position on ring
            θ = 2 * np.pi * j / N_ℓ
            x = r_ℓ * np.cos(θ)
            y = r_ℓ * np.sin(θ)
            
            # Quantum number assignment (interleaved spin scheme)
            m_s = 0.5 if j % 2 == 0 else -0.5
            m_ℓ = (j // 2) - ℓ
            
            # Store data
            points_list.append([x, y])
            r_list.append(r_ℓ)
            theta_list.append(θ)
            ell_list.append(ℓ)
            m_ell_list.append(m_ℓ)
            m_s_list.append(m_s)
            
            # Build index map
            index_map[(ℓ, m_ℓ, m_s)] = linear_idx
            linear_idx += 1
    
    return {
        'points': np.array(points_list),
        'r': np.array(r_list),
        'theta': np.array(theta_list),
        'ell': np.array(ell_list, dtype=int),
        'm_ell': np.array(m_ell_list),
        'm_s': np.array(m_s_list),
        'index_map': index_map,
        'ℓ_max': ℓ_max,
        'n_points': linear_idx,
    }


def get_linear_index(lattice: Dict, ℓ: int, m_ℓ: float, m_s: float) -> int:
    """
    Get linear index for quantum numbers (ℓ, m_ℓ, m_s).
    
    Parameters
    ----------
    lattice : dict
        Lattice dictionary from build_lattice()
    ℓ : int
        Angular momentum quantum number
    m_ℓ : float
        Magnetic quantum number
    m_s : float
        Spin quantum number
    
    Returns
    -------
    int
        Linear index, or -1 if not found
    """
    return lattice['index_map'].get((ℓ, m_ℓ, m_s), -1)


def get_ring_points(lattice: Dict, ℓ: int) -> np.ndarray:
    """
    Get indices of all points on ring ℓ.
    
    Parameters
    ----------
    lattice : dict
        Lattice dictionary
    ℓ : int
        Ring number
    
    Returns
    -------
    np.ndarray
        Array of linear indices for ring ℓ
    """
    return np.where(lattice['ell'] == ℓ)[0]


def count_degeneracies(lattice: Dict) -> Dict[int, int]:
    """
    Count degeneracy for each ℓ shell.
    
    Parameters
    ----------
    lattice : dict
        Lattice dictionary
    
    Returns
    -------
    dict
        Dictionary mapping ℓ -> degeneracy (should be 2(2ℓ+1))
    """
    degeneracies = {}
    for ℓ in range(lattice['ℓ_max'] + 1):
        degeneracies[ℓ] = np.sum(lattice['ell'] == ℓ)
    return degeneracies
