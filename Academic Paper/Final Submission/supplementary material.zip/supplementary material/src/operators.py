"""
Angular Momentum Operators Module
=================================

Constructs SU(2) angular momentum operators on the discrete lattice.

Implements:
- L_z: Diagonal operator with m_ℓ eigenvalues
- L_+, L_-: Ladder operators with standard matrix elements
- L_x, L_y: Cartesian components from ladder operators
- L²: Total angular momentum squared

The operators satisfy exact SU(2) commutation relations to machine precision.
"""

from typing import Dict, Tuple
import numpy as np
from scipy import sparse


def build_Lz(lattice: Dict) -> sparse.csr_matrix:
    """
    Build L_z operator (diagonal).
    
    L_z |ℓ, m_ℓ, m_s⟩ = m_ℓ |ℓ, m_ℓ, m_s⟩
    
    Parameters
    ----------
    lattice : dict
        Lattice dictionary from lattice.build_lattice()
    
    Returns
    -------
    scipy.sparse.csr_matrix
        Diagonal L_z operator
    """
    diagonal = lattice['m_ell']
    return sparse.diags(diagonal, format='csr')


def build_Lplus(lattice: Dict) -> sparse.csr_matrix:
    """
    Build L_+ raising operator.
    
    L_+ |ℓ, m_ℓ, m_s⟩ = sqrt[ℓ(ℓ+1) - m_ℓ(m_ℓ+1)] |ℓ, m_ℓ+1, m_s⟩
    
    Parameters
    ----------
    lattice : dict
        Lattice dictionary
    
    Returns
    -------
    scipy.sparse.csr_matrix
        L_+ operator (sparse, off-diagonal)
    
    Notes
    -----
    Matrix elements use standard angular momentum algebra.
    Only connects states within same ℓ shell.
    """
    n_points = lattice['n_points']
    index_map = lattice['index_map']
    
    row_indices = []
    col_indices = []
    data = []
    
    # Iterate over all lattice points
    for (ℓ, m_ℓ, m_s), idx in index_map.items():
        # Can only raise if m_ℓ < ℓ
        if m_ℓ < ℓ:
            m_ℓ_new = m_ℓ + 1
            idx_new = index_map.get((ℓ, m_ℓ_new, m_s), -1)
            
            if idx_new >= 0:
                # Matrix element: sqrt[ℓ(ℓ+1) - m_ℓ(m_ℓ+1)]
                matrix_element = np.sqrt(ℓ * (ℓ + 1) - m_ℓ * (m_ℓ + 1))
                
                row_indices.append(idx_new)
                col_indices.append(idx)
                data.append(matrix_element)
    
    return sparse.csr_matrix(
        (data, (row_indices, col_indices)),
        shape=(n_points, n_points)
    )


def build_Lminus(lattice: Dict) -> sparse.csr_matrix:
    """
    Build L_- lowering operator.
    
    L_- |ℓ, m_ℓ, m_s⟩ = sqrt[ℓ(ℓ+1) - m_ℓ(m_ℓ-1)] |ℓ, m_ℓ-1, m_s⟩
    
    Parameters
    ----------
    lattice : dict
        Lattice dictionary
    
    Returns
    -------
    scipy.sparse.csr_matrix
        L_- operator (sparse, off-diagonal)
    """
    n_points = lattice['n_points']
    index_map = lattice['index_map']
    
    row_indices = []
    col_indices = []
    data = []
    
    for (ℓ, m_ℓ, m_s), idx in index_map.items():
        # Can only lower if m_ℓ > -ℓ
        if m_ℓ > -ℓ:
            m_ℓ_new = m_ℓ - 1
            idx_new = index_map.get((ℓ, m_ℓ_new, m_s), -1)
            
            if idx_new >= 0:
                # Matrix element: sqrt[ℓ(ℓ+1) - m_ℓ(m_ℓ-1)]
                matrix_element = np.sqrt(ℓ * (ℓ + 1) - m_ℓ * (m_ℓ - 1))
                
                row_indices.append(idx_new)
                col_indices.append(idx)
                data.append(matrix_element)
    
    return sparse.csr_matrix(
        (data, (row_indices, col_indices)),
        shape=(n_points, n_points)
    )


def build_Lx(lattice: Dict) -> sparse.csr_matrix:
    """
    Build L_x operator from ladder operators.
    
    L_x = (L_+ + L_-) / 2
    
    Parameters
    ----------
    lattice : dict
        Lattice dictionary
    
    Returns
    -------
    scipy.sparse.csr_matrix
        L_x operator
    """
    L_plus = build_Lplus(lattice)
    L_minus = build_Lminus(lattice)
    return 0.5 * (L_plus + L_minus)


def build_Ly(lattice: Dict) -> sparse.csr_matrix:
    """
    Build L_y operator from ladder operators.
    
    L_y = (L_+ - L_-) / (2i)
    
    Parameters
    ----------
    lattice : dict
        Lattice dictionary
    
    Returns
    -------
    scipy.sparse.csr_matrix
        L_y operator
    """
    L_plus = build_Lplus(lattice)
    L_minus = build_Lminus(lattice)
    return -0.5j * (L_plus - L_minus)


def build_L_squared(lattice: Dict) -> sparse.csr_matrix:
    """
    Build L² = L_x² + L_y² + L_z² operator.
    
    Should be diagonal with eigenvalues ℓ(ℓ+1).
    
    Parameters
    ----------
    lattice : dict
        Lattice dictionary
    
    Returns
    -------
    scipy.sparse.csr_matrix
        L² operator (should be diagonal)
    
    Notes
    -----
    This is computed via L² = L_x² + L_y² + L_z² as a numerical check.
    The lattice construction should make this exactly diagonal.
    """
    L_x = build_Lx(lattice)
    L_y = build_Ly(lattice)
    L_z = build_Lz(lattice)
    
    return L_x @ L_x + L_y @ L_y + L_z @ L_z


def build_angular_momentum_operators(lattice: Dict) -> Dict[str, sparse.csr_matrix]:
    """
    Build all angular momentum operators at once.
    
    Parameters
    ----------
    lattice : dict
        Lattice dictionary from lattice.build_lattice()
    
    Returns
    -------
    dict
        Dictionary containing operators:
        - 'Lz': L_z operator
        - 'Lplus': L_+ operator
        - 'Lminus': L_- operator
        - 'Lx': L_x operator
        - 'Ly': L_y operator
        - 'L2': L² operator
    """
    operators = {
        'Lz': build_Lz(lattice),
        'Lplus': build_Lplus(lattice),
        'Lminus': build_Lminus(lattice),
        'Lx': build_Lx(lattice),
        'Ly': build_Ly(lattice),
        'L2': build_L_squared(lattice),
    }
    
    return operators


def compute_commutator(A: sparse.csr_matrix, 
                      B: sparse.csr_matrix) -> sparse.csr_matrix:
    """
    Compute commutator [A, B] = AB - BA.
    
    Parameters
    ----------
    A, B : scipy.sparse.csr_matrix
        Operators to compute commutator of
    
    Returns
    -------
    scipy.sparse.csr_matrix
        Commutator [A, B]
    """
    return A @ B - B @ A
