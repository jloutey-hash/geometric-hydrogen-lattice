"""
Validation Module
================

Numerical validation utilities for testing angular momentum operators.

Validates:
1. SU(2) commutation relations: [L_i, L_j] = i ε_ijk L_k
2. L² eigenvalue spectrum: ℓ(ℓ+1) with correct degeneracies
3. Operator properties (hermiticity, etc.)
"""

from typing import Dict, Tuple
import numpy as np
from scipy import sparse

try:
    from . import operators
except ImportError:
    import operators


def validate_commutators(ops: Dict[str, sparse.csr_matrix], 
                        tolerance: float = 1e-12) -> Dict[str, float]:
    """
    Test SU(2) angular momentum commutation relations.
    
    Verifies:
    - [L_x, L_y] = i L_z
    - [L_y, L_z] = i L_x
    - [L_z, L_x] = i L_y
    
    Parameters
    ----------
    ops : dict
        Dictionary of operators from operators.build_angular_momentum_operators()
    tolerance : float, default=1e-12
        Maximum acceptable deviation (Frobenius norm)
    
    Returns
    -------
    dict
        Dictionary containing:
        - 'max_deviation': Maximum deviation across all commutators
        - 'deviations': Dict of individual commutator deviations
        - 'passed': Boolean, True if all deviations < tolerance
    
    Notes
    -----
    Uses Frobenius norm ||[L_i, L_j] - i ε_ijk L_k||_F to measure deviation.
    """
    L_x = ops['Lx']
    L_y = ops['Ly']
    L_z = ops['Lz']
    
    deviations = {}
    
    # [L_x, L_y] - i L_z
    comm_xy = operators.compute_commutator(L_x, L_y)
    expected_xy = 1j * L_z
    deviation_xy = sparse.linalg.norm(comm_xy - expected_xy)
    deviations['[L_x, L_y] - i*L_z'] = deviation_xy
    
    # [L_y, L_z] - i L_x
    comm_yz = operators.compute_commutator(L_y, L_z)
    expected_yz = 1j * L_x
    deviation_yz = sparse.linalg.norm(comm_yz - expected_yz)
    deviations['[L_y, L_z] - i*L_x'] = deviation_yz
    
    # [L_z, L_x] - i L_y
    comm_zx = operators.compute_commutator(L_z, L_x)
    expected_zx = 1j * L_y
    deviation_zx = sparse.linalg.norm(comm_zx - expected_zx)
    deviations['[L_z, L_x] - i*L_y'] = deviation_zx
    
    max_deviation = max(deviations.values())
    passed = max_deviation < tolerance
    
    return {
        'max_deviation': max_deviation,
        'deviations': deviations,
        'passed': passed,
        'tolerance': tolerance,
    }


def validate_spectrum(lattice: Dict, 
                     ops: Dict[str, sparse.csr_matrix],
                     tolerance: float = 1e-10) -> Dict:
    """
    Validate L² eigenvalue spectrum and degeneracies.
    
    Checks:
    1. L² is diagonal (or nearly diagonal)
    2. Eigenvalues match ℓ(ℓ+1) for each state
    3. Degeneracies match 2(2ℓ+1) for each ℓ
    
    Parameters
    ----------
    lattice : dict
        Lattice dictionary
    ops : dict
        Operators dictionary
    tolerance : float, default=1e-10
        Tolerance for eigenvalue comparisons
    
    Returns
    -------
    dict
        Dictionary containing:
        - 'is_diagonal': Bool, is L² diagonal within tolerance?
        - 'off_diagonal_norm': Frobenius norm of off-diagonal part
        - 'eigenvalue_errors': Max deviation from expected ℓ(ℓ+1)
        - 'degeneracies': Dict mapping ℓ -> degeneracy
        - 'expected_degeneracies': Dict mapping ℓ -> 2(2ℓ+1)
        - 'degeneracies_match': Bool, do degeneracies match?
        - 'passed': Bool, all tests passed
    """
    L_sq = ops['L2']
    L_sq_dense = L_sq.toarray()
    L_sq_diag = np.diagonal(L_sq_dense)
    
    # Check if diagonal
    off_diag_norm = np.linalg.norm(L_sq_dense - np.diag(L_sq_diag))
    is_diagonal = off_diag_norm < tolerance
    
    # Check eigenvalues
    eigenvalue_errors = []
    for idx in range(lattice['n_points']):
        ℓ = lattice['ell'][idx]
        expected = ℓ * (ℓ + 1)
        actual = np.real(L_sq_diag[idx])
        error = abs(actual - expected)
        eigenvalue_errors.append(error)
    
    max_eigenvalue_error = max(eigenvalue_errors)
    eigenvalues_correct = max_eigenvalue_error < tolerance
    
    # Check degeneracies
    ℓ_max = lattice['ℓ_max']
    degeneracies = {}
    expected_degeneracies = {}
    
    for ℓ in range(ℓ_max + 1):
        degeneracies[ℓ] = np.sum(lattice['ell'] == ℓ)
        expected_degeneracies[ℓ] = 2 * (2 * ℓ + 1)
    
    degeneracies_match = all(
        degeneracies[ℓ] == expected_degeneracies[ℓ] 
        for ℓ in range(ℓ_max + 1)
    )
    
    passed = is_diagonal and eigenvalues_correct and degeneracies_match
    
    return {
        'is_diagonal': is_diagonal,
        'off_diagonal_norm': off_diag_norm,
        'max_eigenvalue_error': max_eigenvalue_error,
        'eigenvalue_errors': np.array(eigenvalue_errors),
        'degeneracies': degeneracies,
        'expected_degeneracies': expected_degeneracies,
        'degeneracies_match': degeneracies_match,
        'passed': passed,
        'tolerance': tolerance,
    }


def print_commutator_results(results: Dict) -> None:
    """
    Print formatted commutator validation results.
    
    Parameters
    ----------
    results : dict
        Results from validate_commutators()
    """
    print("=" * 60)
    print("SU(2) COMMUTATION RELATION VALIDATION")
    print("=" * 60)
    print()
    print(f"Tolerance: {results['tolerance']:.2e}")
    print()
    
    for relation, deviation in results['deviations'].items():
        status = "✓ PASS" if deviation < results['tolerance'] else "✗ FAIL"
        print(f"{relation:25s}: {deviation:.6e}  {status}")
    
    print()
    print(f"Maximum deviation: {results['max_deviation']:.6e}")
    print()
    
    if results['passed']:
        print("✅ ALL COMMUTATION RELATIONS PASSED")
    else:
        print("❌ SOME COMMUTATION RELATIONS FAILED")
    print()


def print_spectrum_results(results: Dict) -> None:
    """
    Print formatted spectrum validation results.
    
    Parameters
    ----------
    results : dict
        Results from validate_spectrum()
    """
    print("=" * 60)
    print("L² EIGENVALUE SPECTRUM VALIDATION")
    print("=" * 60)
    print()
    print(f"Tolerance: {results['tolerance']:.2e}")
    print()
    
    # Diagonal check
    status = "✓ PASS" if results['is_diagonal'] else "✗ FAIL"
    print(f"L² is diagonal: {status}")
    print(f"  Off-diagonal norm: {results['off_diagonal_norm']:.6e}")
    print()
    
    # Eigenvalue check
    status = "✓ PASS" if results['max_eigenvalue_error'] < results['tolerance'] else "✗ FAIL"
    print(f"Eigenvalues match ℓ(ℓ+1): {status}")
    print(f"  Max error: {results['max_eigenvalue_error']:.6e}")
    print()
    
    # Degeneracy table
    print("Degeneracies:")
    print(f"  {'ℓ':>3s} {'Actual':>8s} {'Expected':>10s} {'Status':>8s}")
    print("  " + "-" * 32)
    
    for ℓ in sorted(results['degeneracies'].keys()):
        actual = results['degeneracies'][ℓ]
        expected = results['expected_degeneracies'][ℓ]
        status = "✓" if actual == expected else "✗"
        print(f"  {ℓ:3d} {actual:8d} {expected:10d} {status:>8s}")
    
    print()
    
    if results['passed']:
        print("✅ ALL SPECTRUM TESTS PASSED")
    else:
        print("❌ SOME SPECTRUM TESTS FAILED")
    print()
