#!/usr/bin/env python
"""
Validation script for discrete angular momentum lattice.

Runs numerical validation tests and prints PASS/FAIL summary.
This script provides a quick check that the package reproduces
the core numerical claims for ℓ_max = 2.
"""

import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from lattice import build_lattice
from operators import build_angular_momentum_operators
from validation import (
    validate_commutators, 
    validate_spectrum,
    print_commutator_results,
    print_spectrum_results
)


def main():
    """Run validation tests and print results."""
    print()
    print("*" * 60)
    print("DISCRETE POLAR LATTICE VALIDATION")
    print("*" * 60)
    print()
    print("Testing ℓ_max = 2 (18 states total)")
    print()
    
    # Build lattice
    print("Building lattice...", end=" ")
    lattice = build_lattice(ℓ_max=2)
    print(f"Done ({lattice['n_points']} points)")
    
    # Build operators
    print("Building operators...", end=" ")
    ops = build_angular_momentum_operators(lattice)
    print("Done")
    print()
    
    # Validate commutators
    commutator_results = validate_commutators(ops, tolerance=1e-12)
    print_commutator_results(commutator_results)
    
    # Validate spectrum
    spectrum_results = validate_spectrum(lattice, ops, tolerance=1e-10)
    print_spectrum_results(spectrum_results)
    
    # Overall summary
    print("=" * 60)
    print("OVERALL SUMMARY")
    print("=" * 60)
    print()
    
    all_passed = commutator_results['passed'] and spectrum_results['passed']
    
    if all_passed:
        print("✅ ALL VALIDATION TESTS PASSED")
        print()
        print("The discrete lattice exactly reproduces:")
        print("  • SU(2) commutation relations to machine precision")
        print("  • L² eigenvalues ℓ(ℓ+1) with correct degeneracies")
        print()
        return 0
    else:
        print("❌ SOME VALIDATION TESTS FAILED")
        print()
        if not commutator_results['passed']:
            print("  • Commutation relations failed")
        if not spectrum_results['passed']:
            print("  • Spectrum validation failed")
        print()
        return 1


if __name__ == '__main__':
    sys.exit(main())
