# Package Architecture

This document describes the architecture of the cleaned discrete polar lattice package.

## Module Dependencies

```
┌─────────────────────────────────────────────────────────┐
│                    User Interface                        │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  scripts/validate.py    tests/           notebooks/     │
│       (CLI)          (Unit Tests)      (Interactive)     │
│         │                 │                 │            │
└─────────┼─────────────────┼─────────────────┼───────────┘
          │                 │                 │
          └─────────────────┴─────────────────┘
                            │
          ┌─────────────────┴─────────────────┐
          │                                    │
          ▼                                    ▼
┌───────────────────┐              ┌───────────────────┐
│  src/validation   │◄─────────────┤  src/operators    │
│  • validate_      │              │  • build_Lz()     │
│    commutators()  │              │  • build_Lplus()  │
│  • validate_      │              │  • build_L2()     │
│    spectrum()     │              │  • compute_       │
│  • print_results()│              │    commutator()   │
└─────────┬─────────┘              └─────────┬─────────┘
          │                                  │
          │                                  │
          └──────────────┬───────────────────┘
                         │
                         ▼
              ┌──────────────────┐
              │   src/lattice    │
              │  • build_lattice()│
              │  • get_linear_   │
              │    index()        │
              │  • count_        │
              │    degeneracies() │
              └──────────────────┘
                         │
                         │ (optional)
                         ▼
              ┌──────────────────┐
              │   src/graph      │
              │  • build_adjacency│
              │  • build_laplacian│
              └──────────────────┘
```

## Data Flow

```
1. Lattice Construction
   ════════════════════
   
   build_lattice(ℓ_max)
        │
        ├─► Generate points on concentric rings
        │   (r_ℓ = 1 + 2ℓ, N_ℓ = 2(2ℓ+1))
        │
        ├─► Assign quantum numbers
        │   (ℓ, m_ℓ, m_s) via spin interleaving
        │
        └─► Return dict with:
            • points: (N, 2) coordinates
            • ell, m_ell, m_s: quantum numbers
            • index_map: (ℓ,m_ℓ,m_s) → index

2. Operator Construction
   ═══════════════════
   
   build_angular_momentum_operators(lattice)
        │
        ├─► build_Lz()      ──► Diagonal with m_ℓ
        ├─► build_Lplus()   ──► Ladder operator (raises m_ℓ)
        ├─► build_Lminus()  ──► Ladder operator (lowers m_ℓ)
        ├─► build_Lx()      ──► (L+ + L-) / 2
        ├─► build_Ly()      ──► (L+ - L-) / 2i
        └─► build_L2()      ──► Lx² + Ly² + Lz²
                │
                └─► Return dict with all operators

3. Validation
   ══════════
   
   validate_commutators(ops)
        │
        ├─► Compute [Lx, Ly] - i*Lz
        ├─► Compute [Ly, Lz] - i*Lx
        ├─► Compute [Lz, Lx] - i*Ly
        └─► Return deviations (should be < 1e-12)
   
   validate_spectrum(lattice, ops)
        │
        ├─► Check L² is diagonal
        ├─► Check eigenvalues = ℓ(ℓ+1)
        ├─► Check degeneracies = 2(2ℓ+1)
        └─► Return test results
```

## Function Call Graph

```
scripts/validate.py
│
├─► build_lattice(ℓ_max=2)
│   └─► Returns lattice dict
│
├─► build_angular_momentum_operators(lattice)
│   ├─► build_Lz(lattice)
│   ├─► build_Lplus(lattice)
│   ├─► build_Lminus(lattice)
│   ├─► build_Lx(lattice)
│   ├─► build_Ly(lattice)
│   └─► build_L_squared(lattice)
│       └─► Returns ops dict
│
├─► validate_commutators(ops)
│   ├─► compute_commutator(Lx, Ly)
│   ├─► compute_commutator(Ly, Lz)
│   ├─► compute_commutator(Lz, Lx)
│   └─► Returns results dict
│
├─► print_commutator_results(results)
│   └─► Formatted output to console
│
├─► validate_spectrum(lattice, ops)
│   └─► Returns results dict
│
└─► print_spectrum_results(results)
    └─► Formatted output to console
```

## Test Organization

```
tests/
│
├─► test_commutators.py
│   ├─► test_commutators_ℓmax2()
│   │   └─► Tests all 3 SU(2) relations
│   │
│   ├─► test_commutators_small_system()
│   │   └─► Tests ℓ_max = 1
│   │
│   ├─► test_hermiticity()
│   │   └─► Tests Lx, Ly, Lz are Hermitian
│   │
│   └─► test_L2_hermitian()
│       └─► Tests L² properties
│
└─► test_spectrum.py
    ├─► test_spectrum_ℓmax2()
    │   └─► Full spectrum validation
    │
    ├─► test_degeneracies_explicit()
    │   └─► Check specific values
    │
    ├─► test_eigenvalue_spectrum()
    │   └─► Check ℓ(ℓ+1) for all states
    │
    ├─► test_L2_is_diagonal()
    │   └─► Check off-diagonal elements
    │
    └─► test_total_state_count()
        └─► Verify total is 18
```

## Notebook Structure

```
notebooks/validate_lmax2.ipynb

Section 1: Build Lattice
   └─► build_lattice(ℓ_max=2)
   └─► Print structure info
   └─► Count degeneracies

Section 2: Visualize Lattice
   └─► Plot 2D structure (colored by ℓ)
   └─► Plot 2D structure (colored by spin)
   └─► Save figures

Section 3: Build Operators
   └─► build_angular_momentum_operators()
   └─► Print operator info

Section 4: Validate Commutators
   └─► validate_commutators()
   └─► print_commutator_results()

Section 5: Validate Spectrum
   └─► validate_spectrum()
   └─► print_spectrum_results()

Section 6: Visualize Operators
   └─► Plot matrix structures (Lz, L+, Lx)
   └─► Show real and imaginary parts

Section 7: Eigenvalue Distribution
   └─► Plot histogram
   └─► Plot eigenvalues by state
   └─► Mark expected values
```

## Key Design Patterns

### 1. Dictionary-Based Data Structures

```python
lattice = {
    'points': np.ndarray,      # (N, 2) coordinates
    'ell': np.ndarray,         # (N,) quantum numbers
    'm_ell': np.ndarray,       # (N,) magnetic QN
    'm_s': np.ndarray,         # (N,) spin QN
    'index_map': dict,         # (ℓ,m_ℓ,m_s) → index
    'ℓ_max': int,             # Maximum ℓ
    'n_points': int,          # Total points
}
```

**Rationale**: Simple, extensible, no classes needed for core functionality.

### 2. Functional API

```python
# Instead of:
lattice_obj = PolarLattice(ℓ_max=2)
operators_obj = AngularMomentumOperators(lattice_obj)

# We use:
lattice = build_lattice(ℓ_max=2)
operators = build_angular_momentum_operators(lattice)
```

**Rationale**: Simpler for reviewers, easier to test, functional style.

### 3. Sparse Matrices

All operators returned as `scipy.sparse.csr_matrix`:

```python
L_z = build_Lz(lattice)  # Returns sparse matrix
```

**Rationale**: Efficient for large systems, standard for quantum operators.

### 4. Validation Functions Return Dicts

```python
results = validate_commutators(ops)
# results = {
#     'passed': bool,
#     'max_deviation': float,
#     'deviations': dict,
#     ...
# }
```

**Rationale**: Easy to inspect, test, and format for output.

## Performance Characteristics

```
Operation                  Time          Scaling
────────────────────────────────────────────────
build_lattice(ℓ_max=2)     < 1 ms       O(N)
build_operators()          ~ 5 ms       O(N²) sparse
validate_commutators()     ~ 10 ms      O(N²) sparse
validate_spectrum()        ~ 5 ms       O(N)
────────────────────────────────────────────────
Total validation           ~ 20 ms      

Where N = Σ 2(2ℓ+1) = total points
For ℓ_max = 2: N = 18
```

## Extension Points

### Add New Operator

```python
# In src/operators.py
def build_new_operator(lattice: Dict) -> sparse.csr_matrix:
    """Build new operator."""
    # Implementation
    return operator
```

### Add New Validation

```python
# In src/validation.py
def validate_new_property(lattice, ops, tolerance=1e-10):
    """Validate new property."""
    # Check property
    return {'passed': bool, 'details': ...}
```

### Add New Test

```python
# In tests/test_new_feature.py
def test_new_feature():
    """Test new feature."""
    lattice = build_lattice(ℓ_max=2)
    # Test logic
    assert condition
```

## File Size Summary

```
Module              Lines    Functions    Classes
──────────────────────────────────────────────────
src/lattice.py        159          4          0
src/operators.py      252          8          0
src/graph.py          112          4          0
src/validation.py     234          4          0
──────────────────────────────────────────────────
Total source          757         20          0

tests/*.py           ~250         10          0

Total                ~1000        30          0
```

## Dependencies

```
Core Runtime
────────────
numpy       ─► Array operations, linear algebra
scipy       ─► Sparse matrices, linalg
matplotlib  ─► (Optional) Plotting in notebooks

Development
───────────
pytest      ─► Unit testing
jupyter     ─► (Optional) Interactive notebooks
```

No exotic dependencies. Standard scientific Python stack.

## Summary

The package architecture follows these principles:

1. **Simplicity**: Functional API, no unnecessary classes
2. **Modularity**: Clear separation of concerns
3. **Testability**: Pure functions, deterministic results
4. **Performance**: Sparse matrices, O(N) and O(N²) algorithms
5. **Extensibility**: Clear extension points documented

All design choices optimize for **reproducibility** and **reviewer understanding**.
