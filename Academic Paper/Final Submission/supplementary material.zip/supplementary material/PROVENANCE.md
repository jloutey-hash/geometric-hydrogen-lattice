# Repository Map and Provenance

## Overview

This document maps the cleaned package structure to the original experimental repository and documents AI contributions.

## Original Repository Structure

The original repository contained:

- **src/**: Multiple Python modules including lattice.py, angular_momentum.py, operators.py, and many application-specific modules (gauge theory, hydrogen atom, RG flow, etc.)
- **tests/**: Phase-specific validation scripts (validate_phase1.py through validate_phase15.py, etc.)
- **Root directory**: Many .md documentation files, run scripts for various phases
- **Academic Paper/**: Manuscript drafts and technical documentation

## Cleaned Package Structure

The cleaned package extracts only the core lattice construction and angular momentum operators needed to validate the central numerical claims.

### Source Modules (cleaned/src/)

| Cleaned Module | Source | Description |
|---------------|--------|-------------|
| `lattice.py` | Original `src/lattice.py` | Extracted core PolarLattice construction, quantum number mapping, removed visualization methods (moved to notebook) |
| `operators.py` | Original `src/angular_momentum.py` | Extracted Lz, L±, Lx, Ly, L² builders and commutator computation |
| `graph.py` | Original `src/operators.py` | Extracted k-NN adjacency and Laplacian builders |
| `validation.py` | Original `src/angular_momentum.py` + `tests/validate_phase1.py` | Extracted commutator tests and spectrum validation, added formatted output functions |

### Test Suite (cleaned/tests/)

| Cleaned Test | Source | Description |
|-------------|--------|-------------|
| `test_commutators.py` | New | Pytest unit tests for SU(2) relations, based on validation logic from original `src/angular_momentum.py::test_commutation_relations()` |
| `test_spectrum.py` | New | Pytest unit tests for L² spectrum, based on `src/angular_momentum.py::verify_L_squared()` |

### Notebook (cleaned/notebooks/)

| Cleaned Notebook | Source | Description |
|-----------------|--------|-------------|
| `validate_lmax2.ipynb` | New | Combines visualization from `src/lattice.py::plot_2d()` with validation from tests, adds eigenvalue plots |

### Scripts (cleaned/scripts/)

| Cleaned Script | Source | Description |
|---------------|--------|-------------|
| `validate.py` | New | CLI wrapper around validation functions, prints formatted PASS/FAIL summary |

## Archived Experimental Files

The following files from the original repository are **not** included in the cleaned package but remain in the parent repository for reference:

### Application-Specific Modules (src/)
- `berry_phase.py`
- `black_hole_entropy.py`
- `electroweak.py`
- `fine_structure.py`
- `fine_structure_deep.py`
- `gauge_theory.py`
- `geometric_ratios.py`
- `hydrogen_lattice.py`
- `improved_radial.py`
- `lqg_operators.py`
- `rg_flow.py`
- `s3_manifold.py`
- `spherical_harmonics_transform.py`
- `spin_networks.py`
- `su3_gauge_theory.py`
- `u1_gauge_theory.py`
- `vacuum_energy.py`
- `wilson_loops.py`
- `convergence.py`
- `quantum_comparison.py`
- `spin.py`
- `visualization.py`

**Rationale**: These modules explore applications beyond the core geometric lattice construction. They are experimental and not required for validating the central numerical claims (exact SU(2) commutators and L² spectrum).

### Phase-Specific Test Scripts (tests/)
All `validate_phase*.py` scripts (phases 1-15, including variants)

**Rationale**: These scripts test incremental development phases. The cleaned package focuses on the minimal reproducible example (ℓ_max = 2) with modern pytest conventions.

### Documentation Files (Root)
- All `PHASE*_SUMMARY.md` files
- `PROJECT_PLAN.md`, `PROGRESS.md`
- Various analysis and summary .md files
- Output dumps (`*_output.txt`)

**Rationale**: These document the research process but are not needed for package users validating numerical claims.

### Run Scripts (Root)
- `run_*.py` scripts for various phases and analyses

**Rationale**: Superseded by `scripts/validate.py` and the test suite.

## AI Contributions

### Human-Provided Elements
1. **Geometric axioms**: Ring radii r_ℓ = 1 + 2ℓ, point counts N_ℓ = 2(2ℓ + 1)
2. **Quantum number assignment**: Spin interleaving scheme (even j → spin-up, odd j → spin-down)
3. **Domain expertise**: Physical interpretation, manuscript structure

### AI-Assisted Elements
1. **Code translation**: Converting geometric rules to numpy/scipy implementations
2. **Operator construction**: Standard angular momentum algebra (L±, Lx, Ly) using textbook formulas
3. **Numerical validation**: Writing test harnesses and computing commutator deviations
4. **Refactoring**: Modularizing code into clean package structure
5. **Documentation**: Docstrings, type hints, README structure

### Joint Human-AI Elements
1. **Exploration**: Testing edge cases, varying parameters, identifying patterns
2. **Debugging**: Fixing indexing errors, ensuring consistency
3. **Presentation**: Creating visualizations and tables for manuscript

## Key Design Decisions

### Why ℓ_max = 2?
- Small enough to run quickly (< 2 minutes total validation time)
- Large enough to demonstrate non-trivial structure (3 shells, 18 states)
- Includes ℓ = 0 (s-orbital), ℓ = 1 (p-orbitals), ℓ = 2 (d-orbitals)

### Why k = 4 for k-NN adjacency?
- Deterministic and well-defined
- Captures local connectivity without over-connecting
- Documented explicitly in `graph.py`

### Why tolerance = 10⁻¹²?
- Conservative: Well above machine epsilon (~10⁻¹⁶) but strict enough to claim "exact"
- Commutators achieve ~10⁻¹⁴ in practice
- Explicitly stated in all test files

## Modification History

- **2026-01-11**: Initial cleaned package creation
  - Extracted core modules from original repository
  - Created pytest test suite
  - Added Jupyter notebook with visualizations
  - Wrote README and documentation

## References to Original Work

- Original lattice construction: `src/lattice.py` (lines 1-419)
- Original angular momentum operators: `src/angular_momentum.py` (lines 1-471)
- Original validation tests: `tests/validate_phase1.py` (lines 1-293)

All numerical algorithms preserve the original logic; only packaging and presentation have changed.
